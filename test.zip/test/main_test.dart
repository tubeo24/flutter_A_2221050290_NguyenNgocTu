import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_project/models/expense.dart';

void main() {
  test('Tạo Expense và chuyển đổi sang/ từ JSON', () {
    final now = DateTime.now();
    final expense = Expense(
      id: '1',
      title: 'Ăn trưa',
      amount: 50000,
      category: 'Ăn uống',
      date: now,
      isIncome: false,
    );

    final json = expense.toJson();
    final expenseFromJson = Expense.fromJson(json);

    expect(expenseFromJson.id, '1');
    expect(expenseFromJson.title, 'Ăn trưa');
    expect(expenseFromJson.amount, 50000);
    expect(expenseFromJson.category, 'Ăn uống');
    expect(expenseFromJson.isIncome, false);
  });
}
