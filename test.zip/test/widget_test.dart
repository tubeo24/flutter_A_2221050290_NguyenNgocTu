import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_project/main.dart';

void main() {
  testWidgets('Ứng dụng hiển thị tiêu đề màn hình chính',
      (WidgetTester tester) async {
    await tester.pumpWidget(const MainApp());

    expect(find.text('Quản lý chi tiêu'), findsOneWidget);
  });
}
