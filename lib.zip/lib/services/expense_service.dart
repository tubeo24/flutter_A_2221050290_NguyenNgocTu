import 'dart:async';

import 'package:localstore/localstore.dart';

import '../models/expense.dart';

/// Lớp làm việc với tầng lưu trữ cục bộ (localstore).
/// Lưu dữ liệu dưới dạng JSON NoSQL trên thiết bị.
class ExpenseService {
  ExpenseService() : _db = Localstore.instance;

  final Localstore _db;
  static const String collectionPath = 'expenses';

  Future<void> saveExpense(Expense expense) async {
    try {
      await _db.collection(collectionPath).doc(expense.id).set(expense.toJson());
    } catch (e) {
      throw Exception('Lỗi khi lưu giao dịch: ' + e.toString());
    }
  }

  Future<List<Expense>> getExpenses() async {
    try {
      final data = await _db.collection(collectionPath).get();
      if (data == null) return [];
      return data.values
          .map((map) => Expense.fromJson(Map<String, dynamic>.from(map)))
          .toList();
    } catch (e) {
      throw Exception('Lỗi khi đọc dữ liệu giao dịch: ' + e.toString());
    }
  }

  Future<void> deleteExpense(String id) async {
    try {
      await _db.collection(collectionPath).doc(id).delete();
    } catch (e) {
      throw Exception('Lỗi khi xóa giao dịch: ' + e.toString());
    }
  }
}
