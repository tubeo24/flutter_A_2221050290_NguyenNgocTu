/// Model đại diện cho một giao dịch thu/chi trong ứng dụng.
class Expense {
  final String id; // định danh duy nhất
  String title;    // mô tả ngắn gọn
  double amount;   // số tiền
  String category; // danh mục (ăn uống, học tập, ...)
  DateTime date;   // ngày giao dịch
  bool isIncome;   // true = khoản thu, false = khoản chi

  Expense({
    required this.id,
    required this.title,
    required this.amount,
    required this.category,
    required this.date,
    this.isIncome = false,
  });

  /// Chuyển đối tượng sang Map (JSON) để lưu trữ.
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'amount': amount,
      'category': category,
      'date': date.toIso8601String(),
      'isIncome': isIncome,
    };
  }

  /// Tạo đối tượng từ Map (JSON).
  factory Expense.fromJson(Map<String, dynamic> json) {
    return Expense(
      id: json['id'] as String,
      title: json['title'] as String? ?? '',
      amount: (json['amount'] as num?)?.toDouble() ?? 0,
      category: json['category'] as String? ?? '',
      date: DateTime.parse(json['date'] as String),
      isIncome: json['isIncome'] as bool? ?? false,
    );
  }

  Expense copyWith({
    String? title,
    double? amount,
    String? category,
    DateTime? date,
    bool? isIncome,
  }) {
    return Expense(
      id: id,
      title: title ?? this.title,
      amount: amount ?? this.amount,
      category: category ?? this.category,
      date: date ?? this.date,
      isIncome: isIncome ?? this.isIncome,
    );
  }

  @override
  String toString() {
    return 'Expense(id: ' + id + ', title: ' + title + ', amount: ' + amount.toString() + ', isIncome: ' + isIncome.toString() + ')';
  }
}
