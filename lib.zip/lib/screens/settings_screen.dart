import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

/// Màn hình cài đặt & demo gọi API http.
/// Ở đây dùng API tỷ giá USD/VND để minh họa việc gọi REST API.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String? _rateText;
  bool _loading = false;

  Future<void> _fetchRate() async {
    setState(() {
      _loading = true;
      _rateText = null;
    });
    try {
      final uri =
          Uri.parse('https://open.er-api.com/v6/latest/USD'); // API public
      final response = await http.get(uri);
      if (response.statusCode == 200) {
        final data = json.decode(response.body) as Map<String, dynamic>;
        final rates = data['rates'] as Map<String, dynamic>;
        final vnd = rates['VND'] as num;
        setState(() {
          _rateText = '1 USD ≈ ' + vnd.toStringAsFixed(0) + ' VND';
        });
      } else {
        setState(() {
          _rateText =
              'Không lấy được tỷ giá (mã lỗi: ' + response.statusCode.toString() + ')';
        });
      }
    } catch (e) {
      setState(() {
        _rateText = 'Lỗi khi gọi API: ' + e.toString();
      });
    } finally {
      setState(() {
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cài đặt & Tỷ giá'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Demo gọi API với http',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: _loading ? null : _fetchRate,
              child: Text(_loading ? 'Đang tải...' : 'Lấy tỷ giá USD/VND'),
            ),
            const SizedBox(height: 12),
            if (_rateText != null)
              Text(
                _rateText!,
                style: const TextStyle(fontSize: 16),
              ),
            const SizedBox(height: 24),
            const Text(
              'Gợi ý mở rộng (chưa triển khai):',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const Text(
              '- Lưu cấu hình người dùng (tên, đơn vị tiền mặc định...).\n'
              '- Cho phép chọn loại tiền tệ khác.',
            ),
          ],
        ),
      ),
    );
  }
}
