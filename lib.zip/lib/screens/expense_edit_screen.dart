import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/expense.dart';
import '../providers/expense_provider.dart';

/// Màn hình tạo / sửa một giao dịch chi tiêu.
class ExpenseEditScreen extends StatefulWidget {
  final Expense? expense;

  const ExpenseEditScreen({super.key, this.expense});

  @override
  State<ExpenseEditScreen> createState() => _ExpenseEditScreenState();
}

class _ExpenseEditScreenState extends State<ExpenseEditScreen> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _titleController;
  late TextEditingController _amountController;
  late TextEditingController _categoryController;
  late DateTime _selectedDate;
  bool _isIncome = false;

  @override
  void initState() {
    super.initState();
    final expense = widget.expense;
    _titleController = TextEditingController(text: expense?.title ?? '');
    _amountController = TextEditingController(
      text: expense != null ? expense.amount.toString() : '',
    );
    _categoryController = TextEditingController(text: expense?.category ?? '');
    _selectedDate = expense?.date ?? DateTime.now();
    _isIncome = expense?.isIncome ?? false;
  }

  @override
  void dispose() {
    _titleController.dispose();
    _amountController.dispose();
    _categoryController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(now.year - 2),
      lastDate: DateTime(now.year + 2),
    );
    if (picked != null) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final provider = Provider.of<ExpenseProvider>(context, listen: false);
    final title = _titleController.text.trim();
    final amount = double.tryParse(_amountController.text.trim()) ?? 0;
    final category = _categoryController.text.trim();

    if (widget.expense == null) {
      await provider.addExpense(
        title: title,
        amount: amount,
        category: category,
        date: _selectedDate,
        isIncome: _isIncome,
      );
    } else {
      await provider.updateExpense(
        widget.expense!,
        title: title,
        amount: amount,
        category: category,
        date: _selectedDate,
        isIncome: _isIncome,
      );
    }

    if (!mounted) return;
    if (provider.errorMessage != null) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(provider.errorMessage!)));
    } else {
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.expense != null;
    final dateText = _selectedDate.day.toString().padLeft(2, "0") +
        '/' +
        _selectedDate.month.toString().padLeft(2, "0") +
        '/' +
        _selectedDate.year.toString();

    return Scaffold(
      appBar: AppBar(
        title: Text(isEditing ? 'Sửa giao dịch' : 'Thêm giao dịch'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: _titleController,
                  decoration: const InputDecoration(
                    labelText: 'Tiêu đề',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Vui lòng nhập tiêu đề';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _amountController,
                  keyboardType:
                      const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                    labelText: 'Số tiền (₫)',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    final text = value?.trim() ?? '';
                    if (text.isEmpty) {
                      return 'Vui lòng nhập số tiền';
                    }
                    final number = double.tryParse(text);
                    if (number == null || number <= 0) {
                      return 'Số tiền phải là số > 0';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _categoryController,
                  decoration: const InputDecoration(
                    labelText: 'Danh mục (Ăn uống, Học tập, ...)',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    const Text('Ngày:'),
                    const SizedBox(width: 8),
                    Text(dateText),
                    const SizedBox(width: 8),
                    TextButton(
                      onPressed: _pickDate,
                      child: const Text('Chọn ngày'),
                    ),
                    const Spacer(),
                    const Text('Khoản thu'),
                    Switch(
                      value: _isIncome,
                      onChanged: (value) {
                        setState(() {
                          _isIncome = value;
                        });
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _save,
                    icon: const Icon(Icons.save),
                    label: const Text('Lưu'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
