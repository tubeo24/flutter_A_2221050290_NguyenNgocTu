import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';

import '../models/expense.dart';
import '../services/expense_service.dart';

/// Provider quản lý trạng thái danh sách giao dịch.
class ExpenseProvider extends ChangeNotifier {
  ExpenseProvider({ExpenseService? service})
      : _service = service ?? ExpenseService();

  final ExpenseService _service;
  final Uuid _uuid = const Uuid();

  List<Expense> _expenses = [];
  bool _isLoading = false;
  String? _errorMessage;

  List<Expense> get expenses => _expenses;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  double get totalIncome =>
      _expenses.where((e) => e.isIncome).fold(0.0, (sum, e) => sum + e.amount);

  double get totalExpense =>
      _expenses.where((e) => !e.isIncome).fold(0.0, (sum, e) => sum + e.amount);

  double get balance => totalIncome - totalExpense;

  Future<void> loadExpenses() async {
    _isLoading = true;
    _errorMessage = null;
    notifyListeners();
    try {
      _expenses = await _service.getExpenses();
    } catch (e) {
      _errorMessage = e.toString();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> addExpense({
    required String title,
    required double amount,
    required String category,
    required DateTime date,
    required bool isIncome,
  }) async {
    if (title.trim().isEmpty) {
      _errorMessage = 'Tiêu đề không được để trống';
      notifyListeners();
      return;
    }
    if (amount <= 0) {
      _errorMessage = 'Số tiền phải lớn hơn 0';
      notifyListeners();
      return;
    }

    final expense = Expense(
      id: _uuid.v4(),
      title: title.trim(),
      amount: amount,
      category: category.trim().isEmpty ? 'Khác' : category.trim(),
      date: date,
      isIncome: isIncome,
    );

    try {
      await _service.saveExpense(expense);
      _expenses.add(expense);
      _errorMessage = null;
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  Future<void> updateExpense(
    Expense expense, {
    String? title,
    double? amount,
    String? category,
    DateTime? date,
    bool? isIncome,
  }) async {
    final updated = expense.copyWith(
      title: title,
      amount: amount,
      category: category,
      date: date,
      isIncome: isIncome,
    );

    try {
      await _service.saveExpense(updated);
      final index = _expenses.indexWhere((e) => e.id == expense.id);
      if (index != -1) {
        _expenses[index] = updated;
      }
      _errorMessage = null;
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
    }
  }

  Future<void> deleteExpense(Expense expense) async {
    try {
      await _service.deleteExpense(expense.id);
      _expenses.removeWhere((e) => e.id == expense.id);
      _errorMessage = null;
      notifyListeners();
    } catch (e) {
      _errorMessage = e.toString();
      notifyListeners();
    }
  }
}
